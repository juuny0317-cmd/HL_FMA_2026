#ifndef NUCLEO_MUX_H
#define NUCLEO_MUX_H

#include "stm32h7xx_hal.h"

void Mux_Init(UART_HandleTypeDef *host_uart);
void Mux_Poll(void);
int Mux_ControlReceive(uint8_t *byte);
HAL_StatusTypeDef Mux_UART_Transmit(UART_HandleTypeDef *uart,
                                    uint8_t *data,
                                    uint16_t length,
                                    uint32_t timeout);
void Mux_FlushLidar(void);

#endif
