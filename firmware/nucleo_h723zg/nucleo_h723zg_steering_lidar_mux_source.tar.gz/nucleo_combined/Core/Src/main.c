/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "nucleo_mux.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* 노트북 명령이 이 시간 이상 끊기면 모든 모터 정지 */
#define COMMAND_TIMEOUT_MS       300U

/* 캘리브레이션 조향 PWM */
#define CAL_PWM_PERCENT          10U

/* 목표 ADC 위치로 이동할 때 사용하는 조향 PWM */
#define STEER_POSITION_PWM_PERCENT 20U

/* 실차 확인을 완료한 부팅 기본 캘리브레이션값 */
#define STEER_ADC_DEFAULT_LEFT   58744U
#define STEER_ADC_DEFAULT_RIGHT  5111U
#define STEER_ADC_DEFAULT_CENTER 31974U

/* 기계적 끝에 닿기 전에 정지하기 위한 절대 안전범위 */
#define STEER_ADC_SAFE_LOW       3000U
#define STEER_ADC_SAFE_HIGH      64500U
#define STEER_ADC_TOLERANCE      300U

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

COM_InitTypeDef BspCOMInit;

ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */

uint8_t rx_byte;

char rx_line[64];
uint8_t rx_index = 0;

int drive_cmd = 0;
int steer_cmd = 0;

/*
 *  0 = calibration off
 * -1 = CAL_LEFT
 * +1 = CAL_RIGHT
 */
int calibration_mode = 0;

/*
 * UART로 받은 조향 목표 ADC값
 * steer_position_active = 1일 때 폐루프 위치 제어 수행
 */
uint32_t steer_target_adc = STEER_ADC_DEFAULT_CENTER;
uint8_t steer_position_active = 0;

/* 실차에서 직접 확인하여 저장하는 캘리브레이션값 */
uint32_t calibration_left_adc = STEER_ADC_DEFAULT_LEFT;
uint32_t calibration_right_adc = STEER_ADC_DEFAULT_RIGHT;
uint32_t calibration_center_adc = STEER_ADC_DEFAULT_CENTER;

uint8_t calibration_left_valid = 1;
uint8_t calibration_right_valid = 1;
uint8_t calibration_center_valid = 1;

/*
 * CAL_STOP 시 어느 끝값을 기록할지 기억한다.
 * -1 = LEFT, +1 = RIGHT, 0 = endpoint 기록 없음
 */
int calibration_capture_mode = 0;

char tx_line[192];

uint32_t steer_adc = 0;

uint32_t last_cmd_time = 0;

uint8_t watchdog_active = 0;

/* USER CODE END PV */


/* Private function prototypes -----------------------------------------------*/

void SystemClock_Config(void);

static void MPU_Config(void);

static void MX_GPIO_Init(void);
static void MX_TIM4_Init(void);
static void MX_ADC1_Init(void);

/* USER CODE BEGIN PFP */

static void ApplyMotorCommands(void);
static void ApplyCalibrationSteering(void);
static void ApplySteeringPositionControl(void);
static void StopAllMotorOutputs(void);
static HAL_StatusTypeDef UpdateSteeringAdc(void);

/* USER CODE END PFP */


/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */


/**
  * @brief  The application entry point.
  * @retval int
  */

int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */


  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();


  /* MCU Configuration--------------------------------------------------------*/

  HAL_Init();


  /* USER CODE BEGIN Init */
  /* USER CODE END Init */


  /* Configure the system clock */
  SystemClock_Config();


  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */


  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_ADC1_Init();


  /* USER CODE BEGIN 2 */

  /*
   * PWM 출력 시작
   *
   * TIM4 CH3 = DRIVE PWM
   * TIM4 CH4 = STEER PWM
   */
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);


  /* 시작할 때 모터 출력은 무조건 0 */
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 0);
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 0);


  /*
   * DIR 초기값 LOW
   *
   * PF3  = DRIVE DIR
   * PG12 = STEER DIR
   */
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_3, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_12, GPIO_PIN_RESET);


  last_cmd_time = HAL_GetTick();

  /* USER CODE END 2 */


  /* Initialize leds */
  BSP_LED_Init(LED_GREEN);
  BSP_LED_Init(LED_YELLOW);
  BSP_LED_Init(LED_RED);


  /* Initialize USER push-button */
  BSP_PB_Init(BUTTON_USER, BUTTON_MODE_EXTI);


  /* Initialize COM1 */
  BspCOMInit.BaudRate   = 921600;
  BspCOMInit.WordLength = COM_WORDLENGTH_8B;
  BspCOMInit.StopBits   = COM_STOPBITS_1;
  BspCOMInit.Parity     = COM_PARITY_NONE;
  BspCOMInit.HwFlowCtl  = COM_HWCONTROL_NONE;


  if (BSP_COM_Init(COM1, &BspCOMInit) != BSP_ERROR_NONE)
  {
    Error_Handler();
  }


  Mux_Init(&hcom_uart[COM1]);

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
      /*
       * ============================================================
       * 1. Ubuntu -> NUCLEO UART 명령 수신
       * ============================================================
       */

      Mux_Poll();
      while (Mux_ControlReceive(&rx_byte))
      {
          /*
           * \r은 무시
           */
          if (rx_byte != '\r')
          {
              /*
               * 한 줄 수신 완료
               */
              if (rx_byte == '\n')
              {
                  rx_line[rx_index] = '\0';

                  int drive_value;
                  int steer_value;
                  unsigned long target_adc_value;


                  /*
                   * --------------------------------------------
                   * PING
                   * --------------------------------------------
                   */
                  if (strcmp(rx_line, "PING") == 0)
                  {
                      char msg[] = "PONG\r\n";

                      Mux_UART_Transmit(&hcom_uart[COM1],
                                        (uint8_t *)msg,
                                        strlen(msg),
                                        HAL_MAX_DELAY);
                  }


                  /*
                   * --------------------------------------------
                   * 일반 주행 명령
                   *
                   * 예:
                   * CMD:30,-20
                   * --------------------------------------------
                   */
                  else if (sscanf(rx_line,
                                  "CMD:%d,%d",
                                  &drive_value,
                                  &steer_value) == 2)
                  {
                      if ((drive_value >= -100) &&
                          (drive_value <= 100) &&
                          (steer_value >= -100) &&
                          (steer_value <= 100))
                      {
                          /*
                           * 캘리브레이션 중지 후
                           * 일반 모드로 전환
                           */
                          calibration_mode = 0;
                          steer_position_active = 0;
                          calibration_capture_mode = 0;


                          drive_cmd = drive_value;
                          steer_cmd = steer_value;


                          /*
                           * 정상 제어 명령 수신 시간 갱신
                           */
                          last_cmd_time = HAL_GetTick();

                          watchdog_active = 0;


                          ApplyMotorCommands();


                          int len = snprintf(
                              tx_line,
                              sizeof(tx_line),
                              "ACK CMD %d %d\r\n",
                              drive_cmd,
                              steer_cmd
                          );


                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)tx_line,
                              len,
                              HAL_MAX_DELAY
                          );
                      }
                      else
                      {
                          char msg[] = "ERROR RANGE\r\n";

                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)msg,
                              strlen(msg),
                              HAL_MAX_DELAY
                          );
                      }
                  }


                  /*
                   * --------------------------------------------
                   * 조향 위치 제어 명령
                   *
                   * 예:
                   * STEER_POS:32000
                   * --------------------------------------------
                   */
                  else if (sscanf(rx_line,
                                  "STEER_POS:%lu",
                                  &target_adc_value) == 1)
                  {
                      if ((target_adc_value >= STEER_ADC_SAFE_LOW) &&
                          (target_adc_value <= STEER_ADC_SAFE_HIGH))
                      {
                          /*
                           * 캘리브레이션/수동 조향을 해제하고
                           * 위치 제어 모드로 전환
                           */
                          calibration_mode = 0;
                          steer_cmd = 0;
                          calibration_capture_mode = 0;

                          steer_target_adc =
                              (uint32_t)target_adc_value;

                          steer_position_active = 1;

                          /*
                           * ADC를 다시 읽고 방향을 결정할 때까지
                           * 기존 조향 PWM은 정지
                           */
                          __HAL_TIM_SET_COMPARE(
                              &htim4,
                              TIM_CHANNEL_4,
                              0
                          );

                          last_cmd_time = HAL_GetTick();
                          watchdog_active = 0;


                          int len = snprintf(
                              tx_line,
                              sizeof(tx_line),
                              "ACK STEER_POS %lu\r\n",
                              (unsigned long)steer_target_adc
                          );


                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)tx_line,
                              len,
                              HAL_MAX_DELAY
                          );
                      }
                      else
                      {
                          char msg[] = "ERROR STEER_POS RANGE\r\n";

                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)msg,
                              strlen(msg),
                              HAL_MAX_DELAY
                          );
                      }
                  }


                  /*
                   * ==================================================
                   * 조향 캘리브레이션 명령
                   * ==================================================
                   */


                  /*
                   * --------------------------------------------
                   * CAL_LEFT
                   *
                   * 최대 300ms 동안만 동작
                   * --------------------------------------------
                   */
                  else if (strcmp(rx_line, "CAL_LEFT") == 0)
                  {
                      /*
                       * 캘리브레이션 중에는
                       * 구동모터 무조건 정지
                       */
                      drive_cmd = 0;
                      steer_cmd = 0;

                      __HAL_TIM_SET_COMPARE(
                          &htim4,
                          TIM_CHANNEL_3,
                          0
                      );

                      __HAL_TIM_SET_COMPARE(
                          &htim4,
                          TIM_CHANNEL_4,
                          0
                      );


                      calibration_mode = -1;
                      steer_position_active = 0;
                      calibration_capture_mode = -1;

                      last_cmd_time = HAL_GetTick();
                      watchdog_active = 0;


                      char msg[] = "ACK CAL_LEFT\r\n";

                      Mux_UART_Transmit(
                          &hcom_uart[COM1],
                          (uint8_t *)msg,
                          strlen(msg),
                          HAL_MAX_DELAY
                      );
                  }


                  /*
                   * --------------------------------------------
                   * CAL_RIGHT
                   * --------------------------------------------
                   */
                  else if (strcmp(rx_line, "CAL_RIGHT") == 0)
                  {
                      drive_cmd = 0;
                      steer_cmd = 0;

                      __HAL_TIM_SET_COMPARE(
                          &htim4,
                          TIM_CHANNEL_3,
                          0
                      );

                      __HAL_TIM_SET_COMPARE(
                          &htim4,
                          TIM_CHANNEL_4,
                          0
                      );


                      calibration_mode = 1;
                      steer_position_active = 0;
                      calibration_capture_mode = 1;

                      last_cmd_time = HAL_GetTick();
                      watchdog_active = 0;


                      char msg[] = "ACK CAL_RIGHT\r\n";

                      Mux_UART_Transmit(
                          &hcom_uart[COM1],
                          (uint8_t *)msg,
                          strlen(msg),
                          HAL_MAX_DELAY
                      );
                  }


                  /*
                   * --------------------------------------------
                   * CAL_STOP
                   *
                   * 조향 즉시 정지
                   * --------------------------------------------
                   */
                  else if (strcmp(rx_line, "CAL_STOP") == 0)
                  {
                      int stopped_capture_mode =
                          calibration_capture_mode;

                      calibration_mode = 0;
                      steer_position_active = 0;

                      drive_cmd = 0;
                      steer_cmd = 0;

                      StopAllMotorOutputs();

                      watchdog_active = 0;


                      HAL_StatusTypeDef adc_status =
                          UpdateSteeringAdc();


                      if (adc_status == HAL_OK)
                      {
                          /*
                           * 좌/우 끝값은 최초 CAL_STOP에서만 저장한다.
                           * 두 끝값을 얻은 뒤 중앙 조정용으로 짧게
                           * 움직일 때 기존 끝값이 덮어써지지 않는다.
                           */
                          if ((steer_adc < STEER_ADC_SAFE_LOW) ||
                              (steer_adc > STEER_ADC_SAFE_HIGH))
                          {
                              int len = snprintf(
                                  tx_line,
                                  sizeof(tx_line),
                                  "ACK CAL_STOP ADC=%lu OUT_OF_SAFE_RANGE\r\n",
                                  (unsigned long)steer_adc
                              );


                              Mux_UART_Transmit(
                                  &hcom_uart[COM1],
                                  (uint8_t *)tx_line,
                                  len,
                                  HAL_MAX_DELAY
                              );
                          }


                          else if ((stopped_capture_mode == -1) &&
                              (calibration_left_valid == 0))
                          {
                              calibration_left_adc = steer_adc;
                              calibration_left_valid = 1;


                              int len = snprintf(
                                  tx_line,
                                  sizeof(tx_line),
                                  "ACK CAL_STOP LEFT_ADC=%lu\r\n",
                                  (unsigned long)calibration_left_adc
                              );


                              Mux_UART_Transmit(
                                  &hcom_uart[COM1],
                                  (uint8_t *)tx_line,
                                  len,
                                  HAL_MAX_DELAY
                              );
                          }


                          else if ((stopped_capture_mode == 1) &&
                                   (calibration_right_valid == 0))
                          {
                              calibration_right_adc = steer_adc;
                              calibration_right_valid = 1;


                              int len = snprintf(
                                  tx_line,
                                  sizeof(tx_line),
                                  "ACK CAL_STOP RIGHT_ADC=%lu\r\n",
                                  (unsigned long)calibration_right_adc
                              );


                              Mux_UART_Transmit(
                                  &hcom_uart[COM1],
                                  (uint8_t *)tx_line,
                                  len,
                                  HAL_MAX_DELAY
                              );
                          }


                          else
                          {
                              int len = snprintf(
                                  tx_line,
                                  sizeof(tx_line),
                                  "ACK CAL_STOP ADC=%lu\r\n",
                                  (unsigned long)steer_adc
                              );


                              Mux_UART_Transmit(
                                  &hcom_uart[COM1],
                                  (uint8_t *)tx_line,
                                  len,
                                  HAL_MAX_DELAY
                              );
                          }
                      }
                      else
                      {
                          char msg[] =
                              "ACK CAL_STOP ADC_ERROR\r\n";


                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)msg,
                              strlen(msg),
                              HAL_MAX_DELAY
                          );
                      }


                      calibration_capture_mode = 0;
                  }


                  /*
                   * --------------------------------------------
                   * SET_CENTER
                   *
                   * 양쪽 끝값을 확인한 뒤 현재 위치를
                   * 실제 정면 CENTER_ADC로 저장
                   * --------------------------------------------
                   */
                  else if (strcmp(rx_line, "SET_CENTER") == 0)
                  {
                      calibration_mode = 0;
                      steer_position_active = 0;
                      calibration_capture_mode = 0;

                      drive_cmd = 0;
                      steer_cmd = 0;

                      StopAllMotorOutputs();


                      if ((calibration_left_valid == 0) ||
                          (calibration_right_valid == 0))
                      {
                          char msg[] =
                              "ERROR SET_CENTER NEED_LEFT_RIGHT\r\n";


                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)msg,
                              strlen(msg),
                              HAL_MAX_DELAY
                          );
                      }
                      else if (UpdateSteeringAdc() != HAL_OK)
                      {
                          char msg[] =
                              "ERROR SET_CENTER ADC\r\n";


                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)msg,
                              strlen(msg),
                              HAL_MAX_DELAY
                          );
                      }
                      else if ((calibration_left_adc <=
                                calibration_right_adc) ||
                               (steer_adc <=
                                calibration_right_adc) ||
                               (steer_adc >=
                                calibration_left_adc))
                      {
                          char msg[] =
                              "ERROR SET_CENTER RANGE\r\n";


                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)msg,
                              strlen(msg),
                              HAL_MAX_DELAY
                          );
                      }
                      else
                      {
                          calibration_center_adc = steer_adc;
                          calibration_center_valid = 1;

                          last_cmd_time = HAL_GetTick();
                          watchdog_active = 0;


                          int len = snprintf(
                              tx_line,
                              sizeof(tx_line),
                              "ACK SET_CENTER CENTER_ADC=%lu\r\n",
                              (unsigned long)calibration_center_adc
                          );


                          Mux_UART_Transmit(
                              &hcom_uart[COM1],
                              (uint8_t *)tx_line,
                              len,
                              HAL_MAX_DELAY
                          );
                      }
                  }


                  /*
                   * --------------------------------------------
                   * CAL_RESET
                   *
                   * 저장된 실차 캘리브레이션값 초기화
                   * --------------------------------------------
                   */
                  else if (strcmp(rx_line, "CAL_RESET") == 0)
                  {
                      calibration_mode = 0;
                      steer_position_active = 0;
                      calibration_capture_mode = 0;

                      drive_cmd = 0;
                      steer_cmd = 0;

                      calibration_left_adc = 0;
                      calibration_right_adc = 0;
                      calibration_center_adc = 0;

                      calibration_left_valid = 0;
                      calibration_right_valid = 0;
                      calibration_center_valid = 0;

                      StopAllMotorOutputs();

                      last_cmd_time = HAL_GetTick();
                      watchdog_active = 0;


                      char msg[] = "ACK CAL_RESET\r\n";


                      Mux_UART_Transmit(
                          &hcom_uart[COM1],
                          (uint8_t *)msg,
                          strlen(msg),
                          HAL_MAX_DELAY
                      );
                  }


                  /*
                   * --------------------------------------------
                   * STATUS
                   * --------------------------------------------
                   */
                  else if (strcmp(rx_line, "STATUS") == 0)
                  {
                      char left_adc_text[16];
                      char right_adc_text[16];
                      char center_adc_text[16];


                      /* STATUS 응답 직전에 현재 ADC를 다시 읽는다. */
                      (void)UpdateSteeringAdc();


                      if (calibration_left_valid != 0)
                      {
                          snprintf(
                              left_adc_text,
                              sizeof(left_adc_text),
                              "%lu",
                              (unsigned long)calibration_left_adc
                          );
                      }
                      else
                      {
                          strcpy(left_adc_text, "NA");
                      }


                      if (calibration_right_valid != 0)
                      {
                          snprintf(
                              right_adc_text,
                              sizeof(right_adc_text),
                              "%lu",
                              (unsigned long)calibration_right_adc
                          );
                      }
                      else
                      {
                          strcpy(right_adc_text, "NA");
                      }


                      if (calibration_center_valid != 0)
                      {
                          snprintf(
                              center_adc_text,
                              sizeof(center_adc_text),
                              "%lu",
                              (unsigned long)calibration_center_adc
                          );
                      }
                      else
                      {
                          strcpy(center_adc_text, "NA");
                      }


                      int len = snprintf(
                          tx_line,
                          sizeof(tx_line),
                          "STATUS DRIVE=%d STEER=%d ADC=%lu LEFT_ADC=%s RIGHT_ADC=%s CENTER_ADC=%s CAL=%d WD=%d TARGET=%lu POS=%d\r\n",
                          drive_cmd,
                          steer_cmd,
                          (unsigned long)steer_adc,
                          left_adc_text,
                          right_adc_text,
                          center_adc_text,
                          calibration_mode,
                          watchdog_active,
                          (unsigned long)steer_target_adc,
                          steer_position_active
                      );


                      Mux_UART_Transmit(
                          &hcom_uart[COM1],
                          (uint8_t *)tx_line,
                          len,
                          HAL_MAX_DELAY
                      );
                  }


                  /*
                   * --------------------------------------------
                   * 잘못된 명령
                   * --------------------------------------------
                   */
                  else
                  {
                      char msg[] = "ERROR\r\n";

                      Mux_UART_Transmit(
                          &hcom_uart[COM1],
                          (uint8_t *)msg,
                          strlen(msg),
                          HAL_MAX_DELAY
                      );
                  }


                  /*
                   * 다음 문자열 받을 준비
                   */
                  rx_index = 0;
              }


              /*
               * 아직 줄 끝이 아니라면 버퍼에 저장
               */
              else
              {
                  if (rx_index < sizeof(rx_line) - 1)
                  {
                      rx_line[rx_index] = rx_byte;
                      rx_index++;
                  }
                  else
                  {
                      /*
                       * 버퍼 overflow 방지
                       */
                      rx_index = 0;
                  }
              }
          }
      }


      /*
       * ============================================================
       * 2. 조향 위치센서 ADC 읽기
       * ============================================================
       */

      (void)UpdateSteeringAdc();


      /*
       * ============================================================
       * 3. Communication Watchdog
       * ============================================================
       *
       * CMD / CAL / STEER_POS 명령이 300ms 이상 오지 않으면
       * 무조건 모든 출력 정지
       */

      if ((HAL_GetTick() - last_cmd_time) >
          COMMAND_TIMEOUT_MS)
      {
          drive_cmd = 0;
          steer_cmd = 0;

          calibration_mode = 0;
          steer_position_active = 0;

          StopAllMotorOutputs();

          watchdog_active = 1;
      }


      /*
       * ============================================================
       * 4. 저속 조향 캘리브레이션
       * ============================================================
       */

      else if (calibration_mode != 0)
      {
          ApplyCalibrationSteering();
      }


      /*
       * ============================================================
       * 5. 저속 조향 위치 제어
       * ============================================================
       */

      else if (steer_position_active != 0)
      {
          ApplySteeringPositionControl();
      }


      Mux_FlushLidar();

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }

  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};


  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);


  __HAL_PWR_VOLTAGESCALING_CONFIG(
      PWR_REGULATOR_VOLTAGE_SCALE2
  );


  while (!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY))
  {
  }


  RCC_OscInitStruct.OscillatorType =
      RCC_OSCILLATORTYPE_HSI;

  RCC_OscInitStruct.HSIState =
      RCC_HSI_DIV1;

  RCC_OscInitStruct.HSICalibrationValue = 64;


  RCC_OscInitStruct.PLL.PLLState =
      RCC_PLL_ON;

  RCC_OscInitStruct.PLL.PLLSource =
      RCC_PLLSOURCE_HSI;

  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 12;
  RCC_OscInitStruct.PLL.PLLP = 1;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;

  RCC_OscInitStruct.PLL.PLLRGE =
      RCC_PLL1VCIRANGE_3;

  RCC_OscInitStruct.PLL.PLLVCOSEL =
      RCC_PLL1VCOWIDE;

  RCC_OscInitStruct.PLL.PLLFRACN = 0;


  if (HAL_RCC_OscConfig(&RCC_OscInitStruct)
      != HAL_OK)
  {
    Error_Handler();
  }


  RCC_ClkInitStruct.ClockType =
      RCC_CLOCKTYPE_HCLK |
      RCC_CLOCKTYPE_SYSCLK |
      RCC_CLOCKTYPE_PCLK1 |
      RCC_CLOCKTYPE_PCLK2 |
      RCC_CLOCKTYPE_D3PCLK1 |
      RCC_CLOCKTYPE_D1PCLK1;


  RCC_ClkInitStruct.SYSCLKSource =
      RCC_SYSCLKSOURCE_PLLCLK;

  RCC_ClkInitStruct.SYSCLKDivider =
      RCC_SYSCLK_DIV1;

  RCC_ClkInitStruct.AHBCLKDivider =
      RCC_HCLK_DIV2;

  RCC_ClkInitStruct.APB3CLKDivider =
      RCC_APB3_DIV2;

  RCC_ClkInitStruct.APB1CLKDivider =
      RCC_APB1_DIV2;

  RCC_ClkInitStruct.APB2CLKDivider =
      RCC_APB2_DIV2;

  RCC_ClkInitStruct.APB4CLKDivider =
      RCC_APB4_DIV2;


  if (HAL_RCC_ClockConfig(
          &RCC_ClkInitStruct,
          FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
  * @brief ADC1 Initialization Function
  * @retval None
  */

static void MX_ADC1_Init(void)
{
  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};


  hadc1.Instance = ADC1;

  hadc1.Init.ClockPrescaler =
      ADC_CLOCK_ASYNC_DIV12;

  hadc1.Init.Resolution =
      ADC_RESOLUTION_16B;

  hadc1.Init.ScanConvMode =
      ADC_SCAN_DISABLE;

  hadc1.Init.EOCSelection =
      ADC_EOC_SINGLE_CONV;

  hadc1.Init.LowPowerAutoWait =
      DISABLE;

  hadc1.Init.ContinuousConvMode =
      DISABLE;

  hadc1.Init.NbrOfConversion = 1;

  hadc1.Init.DiscontinuousConvMode =
      DISABLE;

  hadc1.Init.ExternalTrigConv =
      ADC_SOFTWARE_START;

  hadc1.Init.ExternalTrigConvEdge =
      ADC_EXTERNALTRIGCONVEDGE_NONE;

  hadc1.Init.ConversionDataManagement =
      ADC_CONVERSIONDATA_DR;

  hadc1.Init.Overrun =
      ADC_OVR_DATA_PRESERVED;

  hadc1.Init.LeftBitShift =
      ADC_LEFTBITSHIFT_NONE;

  hadc1.Init.OversamplingMode =
      DISABLE;

  hadc1.Init.Oversampling.Ratio = 1;


  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }


  multimode.Mode =
      ADC_MODE_INDEPENDENT;


  if (HAL_ADCEx_MultiModeConfigChannel(
          &hadc1,
          &multimode) != HAL_OK)
  {
    Error_Handler();
  }


  sConfig.Channel =
      ADC_CHANNEL_10;

  sConfig.Rank =
      ADC_REGULAR_RANK_1;

  sConfig.SamplingTime =
      ADC_SAMPLETIME_64CYCLES_5;

  sConfig.SingleDiff =
      ADC_SINGLE_ENDED;

  sConfig.OffsetNumber =
      ADC_OFFSET_NONE;

  sConfig.Offset = 0;

  sConfig.OffsetSignedSaturation =
      DISABLE;


  if (HAL_ADC_ConfigChannel(
          &hadc1,
          &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
  * @brief TIM4 Initialization Function
  * @retval None
  */

static void MX_TIM4_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};


  htim4.Instance = TIM4;

  htim4.Init.Prescaler = 0;

  htim4.Init.CounterMode =
      TIM_COUNTERMODE_UP;

  htim4.Init.Period = 4799;

  htim4.Init.ClockDivision =
      TIM_CLOCKDIVISION_DIV1;

  htim4.Init.AutoReloadPreload =
      TIM_AUTORELOAD_PRELOAD_DISABLE;


  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }


  sMasterConfig.MasterOutputTrigger =
      TIM_TRGO_RESET;

  sMasterConfig.MasterSlaveMode =
      TIM_MASTERSLAVEMODE_DISABLE;


  if (HAL_TIMEx_MasterConfigSynchronization(
          &htim4,
          &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }


  sConfigOC.OCMode =
      TIM_OCMODE_PWM1;

  sConfigOC.Pulse = 0;

  sConfigOC.OCPolarity =
      TIM_OCPOLARITY_HIGH;

  sConfigOC.OCFastMode =
      TIM_OCFAST_DISABLE;


  if (HAL_TIM_PWM_ConfigChannel(
          &htim4,
          &sConfigOC,
          TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }


  if (HAL_TIM_PWM_ConfigChannel(
          &htim4,
          &sConfigOC,
          TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }


  HAL_TIM_MspPostInit(&htim4);
}


/**
  * @brief GPIO Initialization Function
  * @retval None
  */

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};


  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();


  /*
   * DRIVE DIR 초기 LOW
   */
  HAL_GPIO_WritePin(
      GPIOF,
      GPIO_PIN_3,
      GPIO_PIN_RESET
  );


  /*
   * STEER DIR 초기 LOW
   */
  HAL_GPIO_WritePin(
      GPIOG,
      GPIO_PIN_12,
      GPIO_PIN_RESET
  );


  /*
   * PF3 = DRIVE DIR
   */
  GPIO_InitStruct.Pin =
      GPIO_PIN_3;

  GPIO_InitStruct.Mode =
      GPIO_MODE_OUTPUT_PP;

  GPIO_InitStruct.Pull =
      GPIO_NOPULL;

  GPIO_InitStruct.Speed =
      GPIO_SPEED_FREQ_LOW;

  HAL_GPIO_Init(
      GPIOF,
      &GPIO_InitStruct
  );


  /*
   * PG12 = STEER DIR
   */
  GPIO_InitStruct.Pin =
      GPIO_PIN_12;

  GPIO_InitStruct.Mode =
      GPIO_MODE_OUTPUT_PP;

  GPIO_InitStruct.Pull =
      GPIO_NOPULL;

  GPIO_InitStruct.Speed =
      GPIO_SPEED_FREQ_LOW;

  HAL_GPIO_Init(
      GPIOG,
      &GPIO_InitStruct
  );
}


/* USER CODE BEGIN 4 */


/*
 * ==============================================================
 * 조향 ADC 즉시 갱신
 * ==============================================================
 */

static HAL_StatusTypeDef UpdateSteeringAdc(void)
{
    HAL_StatusTypeDef status;
    HAL_StatusTypeDef stop_status;


    status = HAL_ADC_Start(&hadc1);

    if (status != HAL_OK)
    {
        return status;
    }


    status = HAL_ADC_PollForConversion(
        &hadc1,
        10
    );


    if (status == HAL_OK)
    {
        steer_adc = HAL_ADC_GetValue(&hadc1);
    }


    stop_status = HAL_ADC_Stop(&hadc1);

    if ((status == HAL_OK) &&
        (stop_status != HAL_OK))
    {
        status = stop_status;
    }


    return status;
}


/*
 * ==============================================================
 * 모든 모터 PWM 즉시 정지
 * ==============================================================
 */

static void StopAllMotorOutputs(void)
{
    __HAL_TIM_SET_COMPARE(
        &htim4,
        TIM_CHANNEL_3,
        0
    );


    __HAL_TIM_SET_COMPARE(
        &htim4,
        TIM_CHANNEL_4,
        0
    );
}


/*
 * ==============================================================
 * 일반 CMD 명령을 실제 PWM / DIR로 변환
 * ==============================================================
 */

static void ApplyMotorCommands(void)
{
    int drive_abs;
    int steer_abs;

    uint32_t drive_pulse;
    uint32_t steer_pulse;


    /*
     * --------------------------
     * DRIVE DIR
     * --------------------------
     */

    if (drive_cmd > 0)
    {
        /* 실차 확인 결과: PF3 LOW = 전진 */
        HAL_GPIO_WritePin(
            GPIOF,
            GPIO_PIN_3,
            GPIO_PIN_RESET
        );

        drive_abs = drive_cmd;
    }

    else if (drive_cmd < 0)
    {
        /* 실차 확인 결과: PF3 HIGH = 후진 */
        HAL_GPIO_WritePin(
            GPIOF,
            GPIO_PIN_3,
            GPIO_PIN_SET
        );

        drive_abs = -drive_cmd;
    }

    else
    {
        drive_abs = 0;
    }


    /*
     * --------------------------
     * STEER DIR
     * --------------------------
     */

    if (steer_cmd > 0)
    {
        HAL_GPIO_WritePin(
            GPIOG,
            GPIO_PIN_12,
            GPIO_PIN_SET
        );

        steer_abs = steer_cmd;
    }

    else if (steer_cmd < 0)
    {
        HAL_GPIO_WritePin(
            GPIOG,
            GPIO_PIN_12,
            GPIO_PIN_RESET
        );

        steer_abs = -steer_cmd;
    }

    else
    {
        steer_abs = 0;
    }


    /*
     * 안전 제한
     */
    if (drive_abs > 100)
    {
        drive_abs = 100;
    }

    if (steer_abs > 100)
    {
        steer_abs = 100;
    }


    /*
     * -100 ~ 100
     *      ↓
     * PWM 0 ~ 100%
     */
    drive_pulse =
        ((uint32_t)drive_abs *
         (htim4.Init.Period + 1U))
         / 100U;


    steer_pulse =
        ((uint32_t)steer_abs *
         (htim4.Init.Period + 1U))
         / 100U;


    /*
     * TIM4 CH3 = DRIVE PWM
     */
    __HAL_TIM_SET_COMPARE(
        &htim4,
        TIM_CHANNEL_3,
        drive_pulse
    );


    /*
     * TIM4 CH4 = STEER PWM
     */
    __HAL_TIM_SET_COMPARE(
        &htim4,
        TIM_CHANNEL_4,
        steer_pulse
    );
}


/*
 * ==============================================================
 * 저속 조향 캘리브레이션
 * ==============================================================
 */

static void ApplyCalibrationSteering(void)
{
    uint32_t cal_pulse;


    /* 캘리브레이션 중에는 구동모터를 항상 강제 정지 */
    drive_cmd = 0;

    __HAL_TIM_SET_COMPARE(
        &htim4,
        TIM_CHANNEL_3,
        0
    );


    cal_pulse =
        ((htim4.Init.Period + 1U) *
         CAL_PWM_PERCENT)
         / 100U;


    /*
     * 이동 방향 쪽 안전 한계에 도달하면 조향 정지.
     * 반대 방향 명령은 안전범위 안으로 복귀할 수 있게 허용한다.
     */
    if (((calibration_mode == -1) &&
         (steer_adc >= STEER_ADC_SAFE_HIGH)) ||
        ((calibration_mode == 1) &&
         (steer_adc <= STEER_ADC_SAFE_LOW)))
    {
        __HAL_TIM_SET_COMPARE(
            &htim4,
            TIM_CHANNEL_4,
            0
        );

        calibration_mode = 0;

        return;
    }


    /*
     * --------------------------------------------------
     * CAL_LEFT
     *
     * 현재 가정:
     * PG12 HIGH = 왼쪽
     *
     * 실제 차량에서 반대로 움직이면
     * HIGH / LOW를 서로 바꿀 것
     * --------------------------------------------------
     */
    if (calibration_mode == -1)
    {
        HAL_GPIO_WritePin(
            GPIOG,
            GPIO_PIN_12,
            GPIO_PIN_SET
        );


        __HAL_TIM_SET_COMPARE(
            &htim4,
            TIM_CHANNEL_4,
            cal_pulse
        );
    }


    /*
     * --------------------------------------------------
     * CAL_RIGHT
     *
     * 현재 가정:
     * PG12 LOW = 오른쪽
     * --------------------------------------------------
     */
    else if (calibration_mode == 1)
    {
        HAL_GPIO_WritePin(
            GPIOG,
            GPIO_PIN_12,
            GPIO_PIN_RESET
        );


        __HAL_TIM_SET_COMPARE(
            &htim4,
            TIM_CHANNEL_4,
            cal_pulse
        );
    }


    else
    {
        __HAL_TIM_SET_COMPARE(
            &htim4,
            TIM_CHANNEL_4,
            0
        );
    }
}


/*
 * ==============================================================
 * 목표 ADC값 기반 저속 조향 위치 제어
 *
 * 센서 특성:
 * - 왼쪽으로 이동: ADC 증가
 * - 오른쪽으로 이동: ADC 감소
 * ==============================================================
 */

static void ApplySteeringPositionControl(void)
{
    uint32_t position_pulse;
    uint32_t position_error;


    position_pulse =
        ((htim4.Init.Period + 1U) *
         STEER_POSITION_PWM_PERCENT)
         / 100U;


    /*
     * 현재 센서값 또는 목표값이 안전범위를 벗어나면
     * 위치 제어를 해제하고 즉시 정지
     */
    if ((steer_adc <= STEER_ADC_SAFE_LOW) ||
        (steer_adc >= STEER_ADC_SAFE_HIGH) ||
        (steer_target_adc < STEER_ADC_SAFE_LOW) ||
        (steer_target_adc > STEER_ADC_SAFE_HIGH))
    {
        __HAL_TIM_SET_COMPARE(
            &htim4,
            TIM_CHANNEL_4,
            0
        );

        steer_cmd = 0;
        steer_position_active = 0;

        return;
    }


    if (steer_adc >= steer_target_adc)
    {
        position_error = steer_adc - steer_target_adc;
    }
    else
    {
        position_error = steer_target_adc - steer_adc;
    }


    /*
     * 목표값의 허용오차 안에 들어오면 자동 정지
     */
    if (position_error <= STEER_ADC_TOLERANCE)
    {
        __HAL_TIM_SET_COMPARE(
            &htim4,
            TIM_CHANNEL_4,
            0
        );

        steer_cmd = 0;
        steer_position_active = 0;

        return;
    }


    if (steer_target_adc > steer_adc)
    {
        /* 목표 ADC가 더 크므로 왼쪽으로 이동 */
        HAL_GPIO_WritePin(
            GPIOG,
            GPIO_PIN_12,
            GPIO_PIN_SET
        );

        steer_cmd = (int)STEER_POSITION_PWM_PERCENT;
    }
    else
    {
        /* 목표 ADC가 더 작으므로 오른쪽으로 이동 */
        HAL_GPIO_WritePin(
            GPIOG,
            GPIO_PIN_12,
            GPIO_PIN_RESET
        );

        steer_cmd = -(int)STEER_POSITION_PWM_PERCENT;
    }


    __HAL_TIM_SET_COMPARE(
        &htim4,
        TIM_CHANNEL_4,
        position_pulse
    );
}


/* USER CODE END 4 */


/* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};


  HAL_MPU_Disable();


  MPU_InitStruct.Enable =
      MPU_REGION_ENABLE;

  MPU_InitStruct.Number =
      MPU_REGION_NUMBER0;

  MPU_InitStruct.BaseAddress =
      0x0;

  MPU_InitStruct.Size =
      MPU_REGION_SIZE_4GB;

  MPU_InitStruct.SubRegionDisable =
      0x87;

  MPU_InitStruct.TypeExtField =
      MPU_TEX_LEVEL0;

  MPU_InitStruct.AccessPermission =
      MPU_REGION_NO_ACCESS;

  MPU_InitStruct.DisableExec =
      MPU_INSTRUCTION_ACCESS_DISABLE;

  MPU_InitStruct.IsShareable =
      MPU_ACCESS_SHAREABLE;

  MPU_InitStruct.IsCacheable =
      MPU_ACCESS_NOT_CACHEABLE;

  MPU_InitStruct.IsBufferable =
      MPU_ACCESS_NOT_BUFFERABLE;


  HAL_MPU_ConfigRegion(&MPU_InitStruct);


  HAL_MPU_Enable(
      MPU_PRIVILEGED_DEFAULT
  );
}


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */

void Error_Handler(void)
{
  __disable_irq();

  while (1)
  {
  }
}


#ifdef USE_FULL_ASSERT

void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add implementation */
}

#endif
