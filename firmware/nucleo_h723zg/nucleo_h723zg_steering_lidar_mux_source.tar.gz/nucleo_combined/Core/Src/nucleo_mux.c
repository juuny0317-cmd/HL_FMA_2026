#include "nucleo_mux.h"
#include "main.h"

#define FRAME_END 0xC0U
#define FRAME_ESC 0xDBU
#define FRAME_ESC_END 0xDCU
#define FRAME_ESC_ESC 0xDDU
#define CHANNEL_CONTROL 1U
#define CHANNEL_LIDAR 2U
#define MAX_PAYLOAD 512U
#define MAX_FRAME (MAX_PAYLOAD + 3U)
#define LIDAR_RING_SIZE 16384U
#define HOST_RING_SIZE 2048U
#define CONTROL_RING_SIZE 2048U
#define UART_ERROR_FLAGS (USART_ISR_PE | USART_ISR_FE | USART_ISR_NE | USART_ISR_ORE)
#define UART_ERROR_CLEAR (USART_ICR_PECF | USART_ICR_FECF | USART_ICR_NECF | USART_ICR_ORECF)

static UART_HandleTypeDef *host_uart;
static UART_HandleTypeDef lidar_uart;

static volatile uint8_t host_ring[HOST_RING_SIZE];
static volatile uint32_t host_head, host_tail;
static volatile uint8_t lidar_ring[LIDAR_RING_SIZE];
static volatile uint32_t lidar_head, lidar_tail;
static uint8_t control_ring[CONTROL_RING_SIZE];
static uint32_t control_head, control_tail;
static uint8_t frame_buffer[MAX_FRAME];
static uint16_t frame_length;
static uint8_t frame_escaped, frame_bad;
static volatile uint32_t host_overflows, lidar_overflows, uart_errors;

static uint16_t crc16(const uint8_t *data, uint16_t length)
{
  uint16_t crc = 0xFFFFU;
  for (uint16_t i = 0; i < length; ++i) {
    crc ^= (uint16_t)data[i] << 8;
    for (uint8_t bit = 0; bit < 8U; ++bit) {
      crc = (crc & 0x8000U) ? (uint16_t)((crc << 1) ^ 0x1021U)
                           : (uint16_t)(crc << 1);
    }
  }
  return crc;
}

static void encode_byte(uint8_t byte, uint8_t *out, uint16_t *length)
{
  if (byte == FRAME_END || byte == FRAME_ESC) {
    out[(*length)++] = FRAME_ESC;
    out[(*length)++] = (byte == FRAME_END) ? FRAME_ESC_END : FRAME_ESC_ESC;
  } else {
    out[(*length)++] = byte;
  }
}

static HAL_StatusTypeDef send_frame(uint8_t channel, const uint8_t *data,
                                     uint16_t length, uint32_t timeout)
{
  uint8_t encoded[2U + 2U * MAX_FRAME];
  uint16_t encoded_length = 0U;
  uint16_t crc = 0xFFFFU;

  if (length > MAX_PAYLOAD || host_uart == NULL) return HAL_ERROR;

  encoded[encoded_length++] = FRAME_END;
  encode_byte(channel, encoded, &encoded_length);
  crc ^= (uint16_t)channel << 8;
  for (uint8_t bit = 0; bit < 8U; ++bit) {
    crc = (crc & 0x8000U) ? (uint16_t)((crc << 1) ^ 0x1021U)
                         : (uint16_t)(crc << 1);
  }
  for (uint16_t i = 0; i < length; ++i) {
    encode_byte(data[i], encoded, &encoded_length);
    crc ^= (uint16_t)data[i] << 8;
    for (uint8_t bit = 0; bit < 8U; ++bit) {
      crc = (crc & 0x8000U) ? (uint16_t)((crc << 1) ^ 0x1021U)
                           : (uint16_t)(crc << 1);
    }
  }
  encode_byte((uint8_t)crc, encoded, &encoded_length);
  encode_byte((uint8_t)(crc >> 8), encoded, &encoded_length);
  encoded[encoded_length++] = FRAME_END;
  return HAL_UART_Transmit(host_uart, encoded, encoded_length, timeout);
}

void Mux_Init(UART_HandleTypeDef *uart)
{
  GPIO_InitTypeDef gpio = {0};
  host_uart = uart;

  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_USART2_CLK_ENABLE();
  gpio.Pin = GPIO_PIN_5 | GPIO_PIN_6;
  gpio.Mode = GPIO_MODE_AF_PP;
  gpio.Pull = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  gpio.Alternate = GPIO_AF7_USART2;
  HAL_GPIO_Init(GPIOD, &gpio);

  lidar_uart.Instance = USART2;
  lidar_uart.Init.BaudRate = 256000;
  lidar_uart.Init.WordLength = UART_WORDLENGTH_8B;
  lidar_uart.Init.StopBits = UART_STOPBITS_1;
  lidar_uart.Init.Parity = UART_PARITY_NONE;
  lidar_uart.Init.Mode = UART_MODE_TX_RX;
  lidar_uart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  lidar_uart.Init.OverSampling = UART_OVERSAMPLING_16;
  lidar_uart.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  lidar_uart.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  lidar_uart.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&lidar_uart) != HAL_OK ||
      HAL_UARTEx_DisableFifoMode(&lidar_uart) != HAL_OK) {
    Error_Handler();
  }

  USART2->CR1 |= USART_CR1_RXNEIE_RXFNEIE;
  USART3->CR1 |= USART_CR1_RXNEIE_RXFNEIE;

  HAL_NVIC_SetPriority(USART2_IRQn, 5U, 0U);
  HAL_NVIC_EnableIRQ(USART2_IRQn);
  HAL_NVIC_SetPriority(USART3_IRQn, 5U, 0U);
  HAL_NVIC_EnableIRQ(USART3_IRQn);
}

void USART2_IRQHandler(void)
{
  uint32_t status = USART2->ISR;
  if (status & USART_ISR_RXNE_RXFNE) {
    uint8_t byte = (uint8_t)USART2->RDR;
    uint32_t next = (lidar_head + 1U) & (LIDAR_RING_SIZE - 1U);
    if (next != lidar_tail) {
      lidar_ring[lidar_head] = byte;
      lidar_head = next;
    } else {
      ++lidar_overflows;
    }
  }
  if (status & UART_ERROR_FLAGS) {
    USART2->ICR = UART_ERROR_CLEAR;
    ++uart_errors;
  }
}

void USART3_IRQHandler(void)
{
  uint32_t status = USART3->ISR;
  if (status & USART_ISR_RXNE_RXFNE) {
    uint8_t byte = (uint8_t)USART3->RDR;
    uint32_t next = (host_head + 1U) & (HOST_RING_SIZE - 1U);
    if (next != host_tail) {
      host_ring[host_head] = byte;
      host_head = next;
    } else {
      ++host_overflows;
    }
  }
  if (status & UART_ERROR_FLAGS) {
    USART3->ICR = UART_ERROR_CLEAR;
    ++uart_errors;
  }
}

static void handle_frame(void)
{
  if (frame_bad || frame_length < 3U) return;
  uint16_t payload_length = frame_length - 3U;
  uint16_t received_crc = (uint16_t)frame_buffer[frame_length - 2U]
                        | ((uint16_t)frame_buffer[frame_length - 1U] << 8);
  if (crc16(frame_buffer, frame_length - 2U) != received_crc) return;

  if (frame_buffer[0] == CHANNEL_CONTROL) {
    uint32_t used = (control_head - control_tail) & (CONTROL_RING_SIZE - 1U);
    if (payload_length > CONTROL_RING_SIZE - 1U - used) return;
    for (uint16_t i = 0; i < payload_length; ++i) {
      control_ring[control_head] = frame_buffer[1U + i];
      control_head = (control_head + 1U) & (CONTROL_RING_SIZE - 1U);
    }
  } else if (frame_buffer[0] == CHANNEL_LIDAR && payload_length != 0U) {
    (void)HAL_UART_Transmit(&lidar_uart, &frame_buffer[1], payload_length, 100U);
  }
}

void Mux_Poll(void)
{
  /* Bound work so a busy LIDAR client cannot delay the motor watchdog. */
  uint32_t remaining = 1024U;
  while (host_tail != host_head && remaining-- != 0U) {
    uint8_t byte = host_ring[host_tail];
    host_tail = (host_tail + 1U) & (HOST_RING_SIZE - 1U);

    if (byte == FRAME_END) {
      if (!frame_escaped) handle_frame();
      frame_length = 0U;
      frame_escaped = 0U;
      frame_bad = 0U;
      continue;
    }
    if (frame_bad) continue;
    if (frame_escaped) {
      frame_escaped = 0U;
      if (byte == FRAME_ESC_END) byte = FRAME_END;
      else if (byte == FRAME_ESC_ESC) byte = FRAME_ESC;
      else { frame_bad = 1U; continue; }
    } else if (byte == FRAME_ESC) {
      frame_escaped = 1U;
      continue;
    }
    if (frame_length < MAX_FRAME) frame_buffer[frame_length++] = byte;
    else frame_bad = 1U;
  }
}

int Mux_ControlReceive(uint8_t *byte)
{
  if (control_tail == control_head) return 0;
  *byte = control_ring[control_tail];
  control_tail = (control_tail + 1U) & (CONTROL_RING_SIZE - 1U);
  return 1;
}

HAL_StatusTypeDef Mux_UART_Transmit(UART_HandleTypeDef *uart,
                                    uint8_t *data,
                                    uint16_t length,
                                    uint32_t timeout)
{
  if (uart != host_uart) return HAL_ERROR;
  while (length != 0U) {
    uint16_t chunk = length > MAX_PAYLOAD ? MAX_PAYLOAD : length;
    HAL_StatusTypeDef status = send_frame(CHANNEL_CONTROL, data, chunk, timeout);
    if (status != HAL_OK) return status;
    data += chunk;
    length -= chunk;
  }
  return HAL_OK;
}

void Mux_FlushLidar(void)
{
  uint8_t chunk[MAX_PAYLOAD];
  uint16_t length = 0U;
  if (host_tail != host_head || control_tail != control_head) return;
  while (length < MAX_PAYLOAD && lidar_tail != lidar_head) {
    chunk[length++] = lidar_ring[lidar_tail];
    lidar_tail = (lidar_tail + 1U) & (LIDAR_RING_SIZE - 1U);
  }
  if (length != 0U) (void)send_frame(CHANNEL_LIDAR, chunk, length, 30U);
}
